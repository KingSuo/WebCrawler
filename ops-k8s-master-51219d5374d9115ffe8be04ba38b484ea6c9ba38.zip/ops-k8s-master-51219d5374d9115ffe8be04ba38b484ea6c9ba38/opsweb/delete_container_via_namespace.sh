#!/bin/bash

function message()
{
	set +x
		
    local message_type="$1"
    local message_content="$2"
    
    case "${message_type}" in
    error)
        echo -e "\n\033[31m=============================error=============================\033[0m\n"
        echo -e "\033[31merror: ${message_content}\033[0m"
        echo -e "\n\033[31m=============================error=============================\033[0m\n"
        exit 1
        ;;
    success)
        echo -e "\n\033[32m=============================sucess=============================\033[0m\n"
        echo -e "\033[32msucess: ${message_content}\033[0m"
        echo -e "\n\033[32m=============================sucess=============================\033[0m\n"
        ;;
    warning)
        echo -e "\n\033[36m=============================warning=============================\033[0m\n"
        echo -e "\033[36mwarning: ${message_content}\033[0m"
        echo -e "\n\033[36m=============================warning=============================\033[0m\n"
        ;;
    tips)
        #echo -e "\n\033[44;37m==============================================================\033[0m"
        echo -e "\033[44;37m${message_content}\033[0m"
        #echo -e "\033[44;37m==============================================================\033[0m\n"
        ;; 
    esac
    
    set -x
}

#####显示帮助信息
function usage_help()
{
    set +x
    
    echo -e "\n\033[32m======================================================\n"
    echo -e "功能: 按命名空间和服务名称回收容器"
    echo -e "参数:"
    echo -e "  -s|--service_name: 请填写待回收容器的服务名，多个服务请用,隔开，如需删除所有服务，请填写为all" 
    echo -e "  -n|--name_space: 请填写待回收容器服务的命名空间"
    echo -e "  -h|--help: 显示脚本使用帮助\n"

    echo "For example: $0 -s h5-cwd-vue-admin -n sat-7417"
    echo -e "\n======================================================\033[0m\n"
    exit 1

    set -x
}

####判断kind是否存在
function kind_exist()
{
    local kind="$1"
    local service="$2"
    
    local output=$(kubectl get ${kind} --namespace=${name_space} -l hostname=${service} 2>&1)
    if [ `echo ${output} | grep -c 'No resources found'` -ne 0 ]
    then
        echo "false"
    else
        echo "true"
    fi
}

####获取pod,deployments\replicasets和services名称
function get_kind_name()
{   
    local kind="$1"
    local service="$2"

    kind_name=`kubectl get ${kind} --namespace=${name_space} -l hostname=${service} -o name | awk -F '/' '{print $2}'`
    if [ "${kind_name}" == "" ]
    then
        message "error" "${kind}：服务${service} ${kind}的name获取失败，请检查"
    fi
}

#####回收deployments和services名称
function delete_kind()
{
    local kind="$1"
    local name="$2"
    
    kubectl delete ${kind} ${name} --namespace=${name_space}
    if [ $? -ne 0 ]
    then
        message "error" "${kind}：服务${service} ${kind}的name获取失败，请检查"
    fi


}

####判断namespace是否存在
function namespace_exist()
{
    local output=$(kubectl get ns ${name_space} 2>&1)
    if [ `echo ${output} | grep -c 'Error from server (NotFound)'` -ne 0 ]
    then
        echo "false"
    else
        echo "true"
    fi
}

####删除整个命名空间
function delete_namespace()
{
    kubectl delete ns ${name_space}
    
    if [ $? -ne 0 ]
    then
        message "error" "kubectl delete ns ${name_space}执行失败，请检查"
    else
        message "success" "kubectl delete ns ${name_space}执行成功"
    fi
}


####获取命名空间的nfs本地目录
function get_namespace_nfs_path()
{
    nfs_path=`kubectl get pods --namespace=${name_space} -o json | jq -r  .items[].spec.volumes[].hostPath.path | grep "/docker/nfs" | awk -F '/' '{print $3}' | head -n 1 2>/dev/null`
    
    if [ "${nfs_path}" == "" ]
    then
        message "error" "kubectl get pods --namespace=${name_space} -o json执行失败，请手动检查"
    else
        message "success" "kubectl get pods --namespace=${name_space} -o json执行成功"
    fi
}

####获取服务的本地nfs目录
function get_service_namespace_nfs_path()
{
    local service="$1"
    
    service_nfs_path=(`kubectl get pods --namespace=${name_space} -l hostname=${service} -o json | jq -r  .items[].spec.volumes[].hostPath.path | grep "/docker/nfs" 2>/dev/null`)
    
    if [ "${service_nfs_path}" == "" ]
    then
        message "error" "kubectl get pods --namespace=${name_space} -l hostname=${service} -o json执行失败，请手动检查"
    else
        message "success" "kubectl get pods --namespace=${name_space} -l hostname=${service} -o json执行成功"
    fi
}

#####删除指定目录
function remove_nfs_path()
{
    local path="$1"
    if [ -d ${path} ]
    then
        rm -rf ${path}
        if [ -d ${path} ]
        then
            message "error" "${path}删除失败，请检查"
        else
            message "success" "${path}删除成功"
        fi
    else
        message "warning" "${path}目录不存在，跳过删除"
    fi
}


######## main process
args=`getopt -o s:n:h --long service_name:,name_space:,help -n "$0" -- $@`
eval set -- "${args}"

while true
do
    case "$1" in
        -s|--service_name)
            service_name=$2
            service_name=${service_name//,/ }
            echo "service_name:$2"
            shift 2
            continue
            ;;
        -n|--name_space)
            export name_space=$2
            echo "name_space:$2"
            shift 2
            continue
            ;;
        -h|--help)
            usage_help
            shift
            break
            ;;
        --)
            shift
            break
            ;;
        *) 
            message "error" "the option $1 you given is wrong"
            shift
            break
            ;;
    esac
done

if [ -z "${service_name}" ] || [ -z "${name_space}" ]
then
    usage_help
fi

message "tips" "判断命名空间是否存在"

ns_exist=$(namespace_exist)
if [ "${ns_exist}" == "false" ]
then
    message "error" "命名空间${name_space}不存在，请检查传递的参数是否正确"
else
    message "tips" "获取命名空间${name_space}的nfs目录"
    nfs_path=""
    get_namespace_nfs_path
fi

if [ "${service_name}" == "all" ]
then
    message "tips" "删除命名空间${name_space}"
    delete_namespace
    
    while true
    do
        is_exist=$(namespace_exist)
        if [ "${is_exist}" == "false" ]
        then
            message "success" "命名空间${name_space}已成功删除"
            break
        else
            message "tips" "命名空间${name_space}删除中，等待3秒…"
            sleep 3
        fi
    done
    
    message "tips" "删除命名空间的nfs目录"
    remove_path="/docker/${nfs_path}/${name_space}"
    
    if [ -d "${remove_path}" ]
    then
        remove_nfs_path "${remove_path}"
    else
        message "warning" "${remove_path}目录不存在，跳过删除"
    fi
else
    for service in ${service_name[@]}
    do
        message "tips" "取得服务${service}的nfs目录"
        service_nfs_path=""
        get_service_namespace_nfs_path "${service}" 
        
        kind_array=("deployments" "services")
        for kind in ${kind_array[@]}
        do
            message "tips" "删除服务${service}的${kind}"
            
            message "tips" "判断${service}的${kind}是否存在"
            is_exist=$(kind_exist "${kind}" "${service}")
            if [ "${is_exist}" == "false" ]
            then
                message "error" "${service}的${kind}不存在，请检查传递的参数是否正确"
            else
                kind_name=""
                get_kind_name "${kind}" "${service}"
                delete_kind "${kind}" "${kind_name}"
            fi
            
            while true
            do
                is_exist=$(kind_exist "${kind}" "${service}")
                if [ "${is_exist}" == "false" ]
                then
                    message "success" "${service}的${kind}已成功删除"
                    break
                else
                    message "tips" "${service}的${kind}删除中，等待3秒…"
                    sleep 3
                fi
            done
        done

        message "tips" "判断${service}的pod是否存在"
        is_exist=$(kind_exist "pod" "${service}")
        if [ "${is_exist}" == "false" ]
        then
            message "tips" "${service}的${pod}不存在，跳过检查"
        else
            while true
            do
                is_exist=$(kind_exist "pod" "${service}")
                if [ "${is_exist}" == "false" ]
                then
                    message "success" "${service}的${kind}已成功删除"
                    break
                else
                    message "tips" "${service}的${kind}删除中，等待3秒…"
                    sleep 3
                fi
            done
        fi
        
        message "tips" "删除服务${service}的nfs目录"
        
        for remove_path in ${service_nfs_path[@]}
        do
            if [ -d "${remove_path}" ]
            then
                remove_nfs_path "${remove_path}"
            else
                message "warning" "${remove_path}目录不存在，跳过删除"
            fi
        done
        
        message "tips" "判断命名空间下的所有服务是否都已删除"
        output=$(kubectl get pods --namespace=${name_space} 2>&1)
        if [ `echo ${output} | grep -c 'No resources found'` -ne 0 ]
        then
            message "tips" "由于命名空间${name_space}下的所有pod已删除，遂删除命名空间"

            delete_namespace
            
            while true
            do
                is_exist=$(namespace_exist)
                if [ "${is_exist}" == "false" ]
                then
                    message "success" "命名空间${name_space}已成功删除"
                    break
                else
                    message "tips" "命名空间${name_space}删除中，等待3秒…"
                    sleep 3
                fi
            done
            
            message "tips" "删除命名空间的nfs目录"
            remove_path="/docker/${nfs_path}/${name_space}"
            
            if [ -d "${remove_path}" ]
            then
                remove_nfs_path "${remove_path}"
            else
                message "warning" "${remove_path}目录不存在，跳过删除"
            fi
            
        else
            remain_pods=`kubectl get pods --namespace=${name_space} -o name | awk -F '/' '{print $2}'`
            if [ $? -ne 0 ]
            then
                message "error" "kubectl get pods --namespace=${name_space} -o name执行失败，请手动检查"
            else
                message "warning" "命名空间${name_space}下的还有pod ${remain_pods}，跳过删除命名空间"
            fi
        fi      
        
    done
fi
