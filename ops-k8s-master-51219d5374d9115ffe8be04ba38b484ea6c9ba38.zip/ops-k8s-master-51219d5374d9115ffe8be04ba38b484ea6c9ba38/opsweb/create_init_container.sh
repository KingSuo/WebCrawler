#!/bin/bash

daytime=`date +"%Y%m%d%H%M%S"`
root_dir="${PWD}"

temp_dir="/tmp/create_container/${daytime}"

node_info="${temp_dir}/node.info"

###超过阈值不予创建容器
max_limit_memory_rate=110

### database info for opsweb
db_opsweb_server="192.168.33.173"
db_opsweb_port="33944"
db_opsweb_user="opsweb_r"
db_opsweb_pass="9e2lbtkMP7UiVuyx6b"
db_opsweb_name="ops_cmdb"


### database info for glt
db_glt_server="192.168.33.202"
db_glt_port="3306"
db_glt_user="root"
db_glt_pass='Andy.xaing@!@#123'
db_glt_name="ops_cmdb"


mysql_cmd="mysql --default-character-set=utf8"

###容器所属环境base或者非base(extra)
container_env=""

###docker镜像仓库地址
harbor_server="harbor.ql.corp"

###脚本及配置存放仓库名称
script_repo="ops-k8s"

###yaml等模板文件存放路径
template_path="${root_dir}/${script_repo}/opsweb/template"

###init服务启动脚本存放路径
init_path="${root_dir}/${script_repo}/opsweb/init.d"

###qlconf配置存放目录
qlconf_path="${root_dir}/${script_repo}/opsweb/qlconf"

###脚本存放目录
script_path="${root_dir}/${script_repo}/opsweb/script"

###NFS中yaml文件存放路径
nfs_yaml_dir="/docker/nfs/yamls"


###DNS服务器相关信息
dnsmasq_server_user="root"
dnsmasq_server_ip="10.40.10.37"
dnsmasq_config_file="/etc/dnsmasq.d/app.ql.corp.conf"
addr_nginx_revoxy="10.96.96.96"
dns_backup_dir="${root_dir}/config_backup/dnsmasq"

###revoxy_nginx反向代理相关信息
revoxy_nginx_path="/docker/nfs/nginx-revoxy"


###yaml备份目录
yaml_backup_dir="${root_dir}/config_backup/yamls"


###获取容器状态等待次数
wait_times=6

###等待间隔时间
wait_seconds=5


###
function message()
{
	set +x

    local message_type="$1"
    local message_content="$2"
    
    case "${message_type}" in
    error)
        echo -e "\n\033[31m=============================error=============================\033[0m\n"
        echo -e "\033[31m${message_content}\033[0m"
        echo -e "\n\033[31m=============================error=============================\033[0m\n"
        exit 1
        ;;
    success)
        echo -e "\n\033[32m=============================sucess=============================\033[0m\n"
        echo -e "\033[32m${message_content}\033[0m"
        echo -e "\n\033[32m=============================sucess=============================\033[0m\n"
        ;;
    warning)
        echo -e "\n\033[36m=============================warning=============================\033[0m\n"
        echo -e "\033[36m${message_content}\033[0m"
        echo -e "\n\033[36m=============================warning=============================\033[0m\n"
        ;;
    info)
        #echo -e "\n\033[44;37m===========================info==============================\033[0m"
        echo -e "\033[44;37m${message_content}\033[0m"
        #echo -e "\033[44;37m=============================info=============================\033[0m\n"
        ;;
    esac

	set -x
}


####检查目录并创建
function create_dir()
{
	local dir_name="$1"
	if [ ! -d ${dir_name} ]
	then
		mkdir -pv ${dir_name}
	fi
}


####获取指定node的memory-limit
function get_group_average_limit_mem_rate()
{
	local group_name="$1"
	local group_nodes=(`grep "grandet.nodes.groupname=${group_name}" ${node_info} | awk '{print $1}'`)
	
	local total_limit_memory_rate=0
	for group_node in ${group_nodes[@]}
	do
		local temp_file="${temp_dir}/${group_node}.info"
		kubectl describe node ${group_node} > ${temp_file}
		if [ -s ${temp_file} ]
		then
			local event_line=`grep -n 'Events:' ${temp_file} | awk -F ':' '{print $1}'`
			local resource_line=`expr ${event_line} - 1`
			local limit_memory_rate=`sed -n "${resource_line}p" ${temp_file}| awk -F '\t' '{print $NF}' | sed 's/^[ \t]*//g' | sed 's/[ \t]*$//g' | awk -F '(' '{print $2}' | awk -F '%' '{print $1}'`
			total_limit_memory_rate=`expr ${total_limit_memory_rate} + ${limit_memory_rate} `
		fi
	done

	if [ ${total_limit_memory_rate} -eq 0 ]
	then
		average_limit_mem_rate=0
	else
		average_limit_mem_rate=`awk 'BEGIN{printf "%.2f\n",'${total_limit_memory_rate}'/'${#group_nodes[@]}}`
	fi

	echo ${average_limit_mem_rate}
}

####根据集群资源情况返回使用资源最少的集群名称和使用率
function get_least_average_limit_mem_rate_group_info()
{
	local container_env="$1"  ###base or extra
	local group_names=(`grep  "grandet.nodes.groupname=sat.${container_env}." ${node_info} | awk -F 'grandet.nodes.groupname=' '{print $2}' | awk -F ',' '{print $1}' | sort -u|sed '/^$/d'`)
	
	local least_mem_rate=""
	local least_mem_rate_group=""
	
	for group_name in ${group_names[@]}
	do
		###取得集群的average_limit_mem_rate
		local average_limit_mem_rate=$(get_group_average_limit_mem_rate "${group_name}")
		
		if [ "${least_mem_rate}" == "" ]
		then
			least_mem_rate=${average_limit_mem_rate}
			least_mem_rate_group="${group_name}"
		else
			if [ `echo "${average_limit_mem_rate} < ${least_mem_rate}" | bc` -eq 1 ]
			then
				least_mem_rate=${average_limit_mem_rate}
				least_mem_rate_group="${group_name}"
			fi
		fi
	done
	
	echo "${least_mem_rate_group} ${least_mem_rate}"
}

####获取服务类型、产线和jdk信息等
function get_service_info_cmdb()
{
	local service_name="$1"
	local get_service_info_sql='select cmdb_pro_info.pro_shortname,cmdb_service_info.service_type ,cmdb_service_info.service_port,tomcat_version
		from cmdb_pro_info,cmdb_repo_info,cmdb_service_info
		where cmdb_service_info.service_name="'${service_name}'"
		and cmdb_pro_info.id = cmdb_repo_info.pro_info_id
		and cmdb_service_info.repo_info_id = cmdb_repo_info.id'

	local service_info=`${mysql_cmd} -h${db_opsweb_server} -P${db_opsweb_port} -u${db_opsweb_user} -p${db_opsweb_pass} ${db_opsweb_name} -e "${get_service_info_sql}" -N 2>/dev/null`
	
	echo "${service_info}"
}

####获取服务的域名信息
function get_service_domain_cmdb()
{
	local service_name="$1"
	local get_service_domain_sql='select cmdb_domain_info.domain_name
		from cmdb_service_info,cmdb_domain_info,cmdb_service_domain_info
		where cmdb_service_info.service_name="'${service_name}'"
		and cmdb_domain_info.id = cmdb_service_domain_info.cmdbdomaininfo_id
		and cmdb_service_info.id = cmdb_service_domain_info.cmdbserviceinfo_id'

	local domain_info=(`${mysql_cmd} -h${db_opsweb_server} -P${db_opsweb_port} -u${db_opsweb_user} -p${db_opsweb_pass} ${db_opsweb_name} -e "${get_service_domain_sql}" -N 2>/dev/null`)
	
	echo "${domain_info[@]}"
}

####判断指定类型是否存在
function kind_exist()
{
    local kind="$1"
    local host_name="$2"
	local name_space="$3"
    
    local output=$(kubectl get ${kind} --namespace=${name_space} -l app=${host_name} 2>&1)
    if [ `echo ${output} | grep -c 'No resources found'` -ne 0 ]
    then
        echo "false"
    else
        echo "true"
    fi
}

####获取指定类型的状态
function get_kind_status()
{
    local kind="$1"
    local host_name="$2"
	local name_space="$3"
    
    local status=$(kubectl get ${kind} --namespace=${name_space} -l app=${host_name} --no-headers | awk '{print $3}')
	echo ${status}
}


###检查容器状态
function check_container_status()
{
	local name_space="$1"
	local host_name="$2"

	###检查pod等相关资源是否存在
	#for kind in pod svc rs deploy
	#do
	#	local flag=$(kind_exist "${kind}" "${host_name}" "${name_space}")
	#	if [ "${flag}" == "false" ]
	#	then
	#		message "error" "容器${host_name}的${kind}类型不存在，请检查"
	#	fi
	#done
	
	###检查pod状态
	local try_times=1
	while [ ${try_times} -le ${wait_times} ]
	do
		message "info" "第$try_times次获取命名空间${name_space}中容器${host_name}的pod状态"
		local status=$(get_kind_status "pod" "${host_name}" "${name_space}")
		if [ "${status}" == "Running" ]
		then
			message "success" "命名空间${name_space}中容器${host_name}的pod状态检查通过"
			break
		else
			if [ ${try_times} -eq ${wait_times} ]
			then
				message "error" "命名空间${name_space}中容器${host_name}的pod状态异常，请检查"
			else
				message "warning" "命名空间${name_space}中容器${host_name}的pod状态为${status}，等待${wait_seconds}再检查状态"
			fi
		fi
		
		sleep ${wait_seconds}
		let try_times++
	done
}

###获取集群名称对应的nfs名称
function get_groupname_nfs()
{
	local group_name="$1"
	local nfs_name=`grep  "grandet.nodes.groupname=${group_name}" ${node_info} | awk -F 'kubernetes.io/storage=' '{print $2}' |awk -F ',' '{print $1}' | sort -u`
	
	echo "${nfs_name}"
}

###创建命名空间
function create_name_space()
{
	local name_space="$1"

	kubectl create namespace ${name_space}
	if [ $? -eq 0 ]
	then
		message "success" "namespace ${name_space} 创建成功"
	else
		message "error" "namespace ${name_space} 创建失败，请检查"
	fi
}


###生成yaml文件
function generate_yaml()
{
	local template_file="$1"
	local group_name="$2"
	local service_name="$3"
	local name_space="$4"
	local user_label="$5"
	local product_line="$6"	
	local service_port="$7"
	local image="$8"
	local memory="$9"
	local deploy_type="${10}"
	local domain_name="${11}"
	local service_yaml_file="${12}"
	local nfs_path="${13}"
	local log_path="${14}"
	local container_host_name="${15}"
	local service_type="${16}"
	
	local yaml_file="${template_path}/${template_file}"
	if [ ! -s ${yaml_file} ]
	then
		message "error" "${yaml_file}模板文件不存在，请检查"
	else
		###将服务名的点和下横线转换成-
		cp -a ${yaml_file} ${service_yaml_file}
		
		host_name=${domain_name/.ql.corp/}

		if [ -z ${group_name} ] || [ -z ${service_name} ] || [ -z ${name_space} ] || [ -z ${user_label} ] || [ -z ${product_line} ] || [ -z ${service_port} ] || [ -z ${image} ] || [ -z ${memory} ] || [ -z ${deploy_type} ] || [ -z ${domain_name} ] || [ -z ${host_name} ] || [ -z ${create_user} ] || [ -z ${applicant} ] || [ -z ${nfs_name} ] || [ -z ${log_path} ]
		then
			message "error" "yaml模板替换参数部分为空，请检查"
		else
			sed -i "s/{CONTAINER_HOST_NAME}/${container_host_name}/g" ${service_yaml_file}
			sed -i "s/{GROUP_NAME}/${group_name}/g" ${service_yaml_file}
			sed -i "s/{SERVICE_NAME}/${service_name}/g" ${service_yaml_file}
			sed -i "s/{NAME_SPACE}/${name_space}/g" ${service_yaml_file}
			sed -i "s/{USER_LABEL}/${user_label}/g" ${service_yaml_file}
			sed -i "s/{PRODUCT_LINE}/${product_line}/g" ${service_yaml_file}
			sed -i "s/{SERVICE_PORT}/${service_port}/g" ${service_yaml_file}
			sed -i "s/{SERVICE_TYPE}/${service_type}/g" ${service_yaml_file}
			
			image=${image//\//\\/}
			sed -i "s/{IMAGE}/${image}/g" ${service_yaml_file}
			
			sed -i "s/{MEMORY_EQUEST}/${memory}/g" ${service_yaml_file}
			sed -i "s/{MEMORY_LIMIT}/${memory}/g" ${service_yaml_file}
			sed -i "s/{DEPLOY_TYPE}/${deploy_type}/g" ${service_yaml_file}
			sed -i "s/{DOMAIN_NAME}/${domain_name}/g" ${service_yaml_file}
			sed -i "s/{HOST_NAME}/${host_name}/g" ${service_yaml_file}
			
			nfs_path=${nfs_path//\//\\/}
			sed -i "s/{NFS_PATH}/${nfs_path}/g" ${service_yaml_file}
			
			log_path=${log_path//\//\\/}
			sed -i "s/{LOG_PATH}/${log_path}/g" ${service_yaml_file}

			sed -i "s/{BYWHO}/${create_user}/g" ${service_yaml_file}
			sed -i "s/{APPLICANT}/${applicant}/g" ${service_yaml_file}
		fi
	fi	
}


###生成pod.properties文件
function generate_properties()
{
	local properties_file="$1"
	local service_name="$2"
	local host_name="$3"
	local name_space="$4"
	local image_short="$5"
	local port="$6"

	if [ -s ${properties_file} ]
	then
		message "warning" "${properties_file}已经存在，跳过创建"
	else
		echo "pod.service=${service_name}" > ${properties_file}
		echo "pod.hostname=${host_name}" >> ${properties_file}
		echo "pod.namespace=${name_space}" >> ${properties_file}
		echo "pod.image=${image_short}" >> ${properties_file}
		echo "pod.ports=${port}" >> ${properties_file}
		
		if [ ! -s ${properties_file} ]
		then
			message "error" "${properties_file}文件创建失败，请检查"
		else
			message "success" "${properties_file}文件创建成功"
		fi
	fi
}


####获取命名空间的nfs本地目录
function get_namespace_nfs_path()
{
	local name_space="$1"
	local host_name="$2"
	
    nfs_path=`kubectl get pods -n ${name_space} -l app=${host_name} -o json | jq -r  .items[].spec.volumes[].hostPath.path | grep "/docker/nfs" | awk -F '/' '{print $3}' | head -n 1 2>/dev/null`
    
	echo "${nfs_path}"
}

function is_dir_empty()
{
	local dir_name="$1"
	if [ `find ${dir_name} -type f | wc -l` -eq 0 ]
	then
		echo "true"
	else
		echo "false"
	fi
}

###针对apache和nginx拷贝base中的已有配置文件
function copy_config_from_base()
{
	local service_type="$1"
	local base_hostname="$2"
	local config_path_prefix="$3"

	##获取base容器的nfs路径
	local base_nfs_path=$(get_namespace_nfs_path "sat-base" "${base_hostname}")
	if [ "${base_nfs_path}" == "" ]
    then
        message "error" "${name_space}的nfs路径获取失败，请手动检查"
    else
    	base_nfs_path="/docker/${base_nfs_path}"
    fi

	case "${service_type}" in
		apache)
			for config_type in httpd nginx
			do
				empty_flag=$(is_dir_empty "${base_nfs_path}/sat-base/Apps/php/${config_type}")
				
				if [ -d "${base_nfs_path}/sat-base/Apps/php/${config_type}" ] && [ "${empty_flag}" == "false" ]
				then
					cp -a ${base_nfs_path}/sat-base/Apps/php/${config_type}/* ${config_path_prefix}/${config_type}/
				else
					if [ -d ${base_nfs_path}/sat-base/config/${base_hostname}/${config_type} ]
					then
						empty_flag=$(is_dir_empty "${base_nfs_path}/sat-base/config/${base_hostname}/${config_type}")
						if [ "${empty_flag}" == "false" ]
						then
							cp -a ${base_nfs_path}/sat-base/config/${base_hostname}/${config_type}/* ${config_path_prefix}/${config_type}/
						else
							message "warning" "${base_nfs_path}/sat-base/config/${base_hostname}/${config_type}为空，跳过拷贝"
						fi
					else
						message "warning" "${base_nfs_path}/sat-base/config/${base_hostname}/${config_type}不存在，跳过配置文件拷贝"
					fi
				fi
			done
			
			;;
		nginx)
			empty_flag=$(is_dir_empty "${base_nfs_path}/sat-base/nginx/${base_hostname}")
			
			if [ -d "${base_nfs_path}/sat-base/nginx/${base_hostname}" ] && [ "${empty_flag}" == "false" ]
			then
				cp -a ${base_nfs_path}/sat-base/nginx/${base_hostname}/* ${config_path_prefix}/${service_type}/
			else
				if [ -d ${base_nfs_path}/sat-base/config/${base_hostname}/${service_type} ]
				then
					empty_flag=$(is_dir_empty "${base_nfs_path}/sat-base/config/${base_hostname}/${service_type}")
					if [ "${empty_flag}" == "false" ]
					then
						cp -a ${base_nfs_path}/sat-base/config/${base_hostname}/${service_type}/* ${config_path_prefix}/${service_type}/
					else
						message "warning" "${base_nfs_path}/sat-base/config/${base_hostname}/${service_type}为空，跳过拷贝"
					fi
				else
					message "warning" "${base_nfs_path}/sat-base/config/${base_hostname}/${service_type}不存在，跳过配置文件拷贝"
				fi
			fi
			
			;;
		*)
			message "warning" "${service_type}不需要拷贝配置文件，跳过处理"
			;;
	esac		
}

###针对apache拷贝git仓库中已有配置文件
function copy_config_from_git
{
	local config_path_prefix="$1"
	
	if [ "${service_type}" == "apache" ]
	then
		for config_type in httpd nginx
		do	
			if [ -e "${template_path}/php-${config_type}.zip" ]
			then
				unzip ${template_path}/php-${config_type}.zip -d ${config_path_prefix}/${config_type}
			else
				message "error" "${template_path}/php-${config_type}.zip不存在，请检查"
			fi
		done
	else
		message "warning" "${service_type}不需从git中拷贝配置文件，跳过处理"
	fi
}


###更新revoxy-conf配置
function config_revoxy_nginx()
{
	local host_name="$1"
	local domain_name="$2"
	local service_port="$3"

	if [ ! -d ${revoxy_nginx_path} ]
	then
		message "error" "${revoxy_nginx_path}路径不存在，请检查"
	else
		if [ ! -s ${revoxy_nginx_path}/${domain_name}.conf ]
		then
			cp -a ${template_path}/nginx-revoxy.conf ./${domain_name}.conf
			
			sed -i "s/{HOST_NAME}/${host_name}/g" ${domain_name}.conf
			sed -i "s/{DOMAIN_NAME}/${domain_name}/g" ${domain_name}.conf
			sed -i "s/{SERVICE_PORT}/${service_port}/g" ${domain_name}.conf
			
			cp ${domain_name}.conf ${revoxy_nginx_path}/${domain_name}.conf

			local revoxy_pod_name=`kubectl get po -n sat-base -l app=nginx-revoxy -o name|awk -F '/' '{print $2}'`
			
			if [ "${revoxy_pod_name}" == "" ]
			then
				message "error" "revoxy_pod_name 获取失败，请检查"
			else
				kubectl exec ${revoxy_pod_name} -n sat-base -- bash -c '/etc/init.d/nginx reload'
				if [ $? -eq 0 ]
				then
					message "success" "/etc/init.d/nginx -s reload执行成功"
				else
					message "error" "/etc/init.d/nginx -s reload执行失败，请检查"
				fi
			fi
		else
			message "warning" "${revoxy_nginx_path}/${domain_name}.conf已经存在，跳过处理"
		fi
	fi
}

###DNS配置初始化
function config_dnsmasq()
{
	local domain_name="$1"
	local file_name=`basename ${dnsmasq_config_file}`
	local local_dns_file="${temp_dir}/${file_name}"
	
	create_dir ${dns_backup_dir}
	
	scp ${dnsmasq_server_user}@${dnsmasq_server_ip}:${dnsmasq_config_file} ${local_dns_file}

	if [ -e ${local_dns_file} ]
	then
		###备份DNS配置文件
		cp -a ${local_dns_file} ${dns_backup_dir}/${file_name}-${daytime}
		
		local num=`grep -c "^address=/${domain_name}/${addr_nginx_revoxy}$" ${local_dns_file}`
		case ${num} in
			1)
				message "warning" "${dnsmasq_config_file}中${domain_name}已存在，跳过配置"
				;;
			0)
				###追加配置并重启服务
				echo "address=/${domain_name}/${addr_nginx_revoxy}" >> ${local_dns_file}
				scp ${local_dns_file} ${dnsmasq_server_user}@${dnsmasq_server_ip}:${dnsmasq_config_file}
				
				ssh ${dnsmasq_server_user}@${dnsmasq_server_ip} "systemctl restart dnsmasq"
				
				if [ `ssh  ${dnsmasq_server_user}@${dnsmasq_server_ip} "systemctl status dnsmasq" | grep -c 'Active: active (running)'` -eq 1 ]
				then
					message "success" "${dnsmasq_config_file}中成功配置${domain_name}"
				else
					message "error" "${dnsmasq_config_file}中未成功配置${domain_name}，请检查"
				fi
				;;
			*)
				message "warning" "${dnsmasq_config_file}中${domain_name}存在多个配置，请检查"
				;;
		esac
	else
		message "error" "${dnsmasq_config_file}文件下载失败，请检查"
	fi
}

###初始化处理snowwalking-agent
function init_snowwalking_agent
{
	local nfs_path="$1"
	local name_space="$2"
	local host_name="$3"
	
	####拷贝snowwalking-agent
	if [ -d ${script_path}/snowwalking-agent ]
	then
		cp -a ${script_path}/snowwalking-agent ${nfs_path}/${name_space}/script/${host_name}
	else
		message "error" "${script_path}/snowwalking-agent不存在，请检查"
	fi
} 

###修改JVM参数
function config_jvm()
{
	local jvm_xms="$1"
	local jvm_xmx="$2"
	local config_file="$3"
	
	###修改JVM参数
	if [ -e ${config_file} ]
	then
		sed -i "s/{XMS_MEM}/${jvm_xms}/g" ${config_file}
		sed -i "s/{XMX_MEM}/${jvm_xmx}/g" ${config_file}
	else
		message "error" "${config_file}文件不存在，请检查"
	fi
}

###判断命名空间是否存在
function namespace_exist()
{
	local name_space="$1"
	kubectl get ns ${name_space} >/dev/null 2>&1
	if [ $? -eq 0 ]
	then
		echo "true"
	else
		echo "false"
	fi
}

###创建容器并创建挂载相关目录
function create_container()
{
	local group_name="$1"
	local service_name="$2"
	local name_space="$3"
	local user_label="$4"
	local domain_name="$5"
	local host_name="$6"
	local nfs_path="$7"
	local product_line="$8"
	local service_type="$9"
	local service_port="${10}"
	local tomcat_version="${11}"

	local image=""
	local memory=""
	local deploy_type=""
	local template_file=""
	local service_yaml_file="${temp_dir}/${service_name}_${name_space}.yaml"
	local log_path="/docker/data"

	###由于yaml中的name不支持下横线和点，做特殊处理
	local container_host_name=${host_name//./-}
	container_host_name=${host_name//_/-}

	##挂载相关目录初始化
	
	###workdirs应用安装目录
	create_dir ${nfs_path}/${name_space}/workdirs/${host_name}
	
	###applogs应用日志目录
	create_dir ${nfs_path}/${name_space}/applogs/${host_name}

	###script应用配置相关目录
	create_dir ${nfs_path}/${name_space}/script/${host_name}
	cp -a ${script_path}/restart_service.sh ${nfs_path}/${name_space}/script/${host_name}

	###qlconf应用配置相关目录
	create_dir ${nfs_path}/${name_space}/qlconf/${host_name}
	cp -a ${qlconf_path}/root.config ${nfs_path}/${name_space}/qlconf/${host_name}
	
	###yum rpm源repo文件存放目录
	create_dir ${nfs_path}/${name_space}/yum/${host_name}
	cp -a ${template_path}/yum-QLrelAll.repo ${nfs_path}/${name_space}/yum/${host_name}/QLrelAll.repo

	###cat配置文件存放目录
	create_dir "${nfs_path}/${name_space}/config/${host_name}/cat"
	cp -a ${template_path}/cat-client.xml ${nfs_path}/${name_space}/config/${host_name}/cat/client.xml
	
	case "${service_type}" in
		jar1.7)
			image="${harbor_server}/new_uat/centos6.7_netty:sunjdk1.7.0_v1.1"
			image_short="netty_1.7"
			memory="2048M"
			jvm_xms="256M"
			jvm_xmx="1024M"
			deploy_type="netty-jdk1.7"
			template_file="netty.yaml"
	
			###initd启动目录
			create_dir ${nfs_path}/${name_space}/init.d/${host_name}
	
			###init.d目录初始化
			cp -a ${init_path}/netty_init.d/* ${nfs_path}/${name_space}/init.d/${host_name}
			chmod a+x ${nfs_path}/${name_space}/init.d/${host_name}/*
			
			if [ -e ${nfs_path}/${name_space}/init.d/${host_name}/start ]
			then
				mv ${nfs_path}/${name_space}/init.d/${host_name}/start ${nfs_path}/${name_space}/init.d/${host_name}/${service_name}
				
				###修改JVM参数
				config_jvm "${jvm_xms}" "${jvm_xmx}" "${nfs_path}/${name_space}/init.d/${host_name}/${service_name}"
			else
				message "error" "${nfs_path}/${name_space}/init.d/${host_name}/start文件不存在，请检查"
			fi
			
			####初始化snowwalking-agent
			init_snowwalking_agent "${nfs_path}" "${name_space}" "${host_name}"
			
			;;
		jar1.8)
			image="${harbor_server}/new_uat/centos6.7_netty:sunjdk1.8.0_v1.1"
			image_short="netty_1.8"
			memory="2048M"
			jvm_xms="256M"
			jvm_xmx="1024M"
			deploy_type="netty-jdk1.8"
			template_file="netty.yaml"
			
			###initd启动目录
			create_dir ${nfs_path}/${name_space}/init.d/${host_name}
			
			###init.d目录初始化
			cp -a ${init_path}/netty_init.d/* ${nfs_path}/${name_space}/init.d/${host_name}
			chmod a+x ${nfs_path}/${name_space}/init.d/${host_name}/*
			
			if [ -e ${nfs_path}/${name_space}/init.d/${host_name}/start ]
			then
				mv ${nfs_path}/${name_space}/init.d/${host_name}/start ${nfs_path}/${name_space}/init.d/${host_name}/${service_name}
				###修改JVM参数
				config_jvm "${jvm_xms}" "${jvm_xmx}" "${nfs_path}/${name_space}/init.d/${host_name}/${service_name}"
			else
				message "error" "${nfs_path}/${name_space}/init.d/${host_name}/start文件不存在，请检查"
			fi

			####初始化snowwalking-agent
			init_snowwalking_agent "${nfs_path}" "${name_space}" "${host_name}"
			
			;;
		war1.7)
			image_short="tomcat_1.7"
			image="${harbor_server}/new_uat/centos6.7_tomcat7:sunjdk1.7.0_v1.1"
			memory="8192M"
			jvm_xms="1024M"
			jvm_xmx="6144M"
			deploy_type="tomcat7-jdk1.7"
			template_file="tomcat7.yaml"
			
			###initd启动目录
			create_dir ${nfs_path}/${name_space}/init.d/${host_name}
			
			###init.d目录初始化
			cp -a ${init_path}/tomcat_init.d/* ${nfs_path}/${name_space}/init.d/${host_name}
			
			###修改JVM参数
			config_jvm "${jvm_xms}" "${jvm_xmx}" "${nfs_path}/${name_space}/init.d/${host_name}/tomcat7"

			####初始化snowwalking-agent
			init_snowwalking_agent "${nfs_path}" "${name_space}" "${host_name}"
			
			;;
		war1.8)
			memory="8192M"
			jvm_xms="1024M"
			jvm_xmx="6144M"
			template_file="tomcat8.yaml"
			
			if [ "${tomcat_version}" == "tomcat8" ]
			then
				image_short="tomcat8_1.8"
				image="${harbor_server}/new_uat/centos6.7_tomcat8:sunjdk1.8.0_v1.1"
				deploy_type="tomcat8-jdk1.8"

				###initd启动目录
				create_dir ${nfs_path}/${name_space}/init.d/${host_name}
			
				###init.d目录初始化
				cp -a ${init_path}/tomcat8_init.d/* ${nfs_path}/${name_space}/init.d/${host_name}
				chmod a+x ${nfs_path}/${name_space}/init.d/${host_name}/*
				
				###修改JVM参数
				config_jvm "${jvm_xms}" "${jvm_xmx}" "${nfs_path}/${name_space}/init.d/${host_name}/tomcat8"
			
			else
				image_short="tomcat_1.8"
				image="harbor.ql.corp/new_uat/centos6.7_tomcat7:sunjdk1.8.0_v1.1"
				deploy_type="tomcat7-jdk1.8"

				###initd启动目录
				create_dir ${nfs_path}/${name_space}/init.d/${host_name}
				
				###init.d目录初始化
				cp -a ${init_path}/tomcat_init.d/* ${nfs_path}/${name_space}/init.d/${host_name}
				chmod a+x ${nfs_path}/${name_space}/init.d/${host_name}/*
				
				###修改JVM参数
				config_jvm "${jvm_xms}" "${jvm_xmx}" "${nfs_path}/${name_space}/init.d/${host_name}/tomcat7"
			fi
			
			####初始化snowwalking-agent
			init_snowwalking_agent "${nfs_path}" "${name_space}" "${host_name}"

			;;
		nginx)
			image_short="nginx"
			image="${harbor_server}/library/centos6:nginx_v1.10"
			memory="1024M"
			deploy_type="nginx"
			template_file="nginx.yaml"
			
			##nginx应用配置目录
			create_dir ${nfs_path}/${name_space}/config/${host_name}/nginx
			
			;;
		apache)
			image_short="webserver"
			image="${harbor_server}/new_uat/webserver:v1.0"
			memory="1024M"
			deploy_type="apache"
			template_file="apache.yaml"
			
			##nginx应用配置目录
			create_dir ${nfs_path}/${name_space}/config/${host_name}/nginx
			
			##httpd应用配置目录
			create_dir ${nfs_path}/${name_space}/config/${host_name}/httpd
			;;
		*)
			message "error" "不支持服务类型${service_type},跳过容器创建"
			;;
	esac

	###生成pod.properties文件
	generate_properties "${nfs_path}/${name_space}/script/${host_name}/pod.properties" "${service_name}" "${host_name}" "${name_space}" "${image_short}" "${service_port}:22022:20880"
			
	generate_yaml "${template_file}" "${group_name}" "${service_name}" "${name_space}" "${user_label}" "${product_line}" "${service_port}" "${image}" "${memory}" "${deploy_type}" "${domain_name}" "${service_yaml_file}" "${nfs_path}" "${log_path}" "${container_host_name}" "${service_type}"

	if [ ! -s ${service_yaml_file} ]
	then
		message "error" "服务${service_name}的yaml文件生成失败，请检查"
	else
		message "success" "服务${service_name}的yaml文件生成成功"
	fi

	###创建命名空间
	local ns_flag=$(namespace_exist "${name_space}")
	if [ "${ns_flag}" == "true" ]
	then
		message "warning" "命名空间${name_space}已存在，跳过创建"
	else
		create_name_space "${name_space}"
	fi
	
	###创建容器
	kubectl create -f ${service_yaml_file}
	if [ $? -eq 0 ]
	then
		check_container_status "${name_space}" "${host_name}"

		###拷贝yaml文件到nfs中
		if [ "${container_env}" == "base" ]
		then
			cp -a ${service_yaml_file} ${nfs_yaml_dir}/sat-base
		else
			cp -a ${service_yaml_file} ${nfs_yaml_dir}/other-yamls
		fi

		create_dir ${yaml_backup_dir}
		cp -a ${service_yaml_file} ${yaml_backup_dir}
		
		###将容器信息插入葛朗台表中
		local glt_flag=$(is_existing_grandet "${service_name}")
		if [ "${glt_flag}" == "false" ]
		then
			insert_grandet "${service_name}" "${host_name}" "${image_short}" "${memory}" "${service_port}"
		fi
 		
	else
		message "error" "kubectl create -f ${service_yaml_file} 执行失败，请检查"
	fi
}


###安装qlconfig
function intall_qlconfig()
{
	local name_space="$1"
	local host_name="$2"
	
	local pod_name=`kubectl get pod -n ${name_space} -l app=${host_name} -o name | awk -F '/' '{print $2}'`
	if [ "${pod_name}" == "" ]
	then
		message "error" "${host_name}的pod_name获取失败，请检查"
	else
		kubectl exec ${pod_name} -n ${name_space} -- bash -c 'yum install -y qlconfig'
		if [ $? -eq 0 ]
		then
			message "success" "kubectl exec ${pod_name} -n ${name_space} -- bash -c 'yum install -y qlconfig' 执行成功"
		else
			message "warning" "kubectl exec ${pod_name} -n ${name_space} -- bash -c 'yum install -y qlconfig'执行失败，请检查"
		fi
	fi
}


####脚本帮助
function usage_help()
{
	set +x
	
    echo -e "\n\033[32m======================================================\n"
    echo -e "功能: 添加容器并环境初始化"
    echo -e "参数:"
    echo -e "  -d|--details: 请填写josn格式的容器相关信息" 
    echo -e "  -a|--applicant: 请填写容器申请人"
    echo -e "  -c|--create_user: 请填写容器创建人"
    echo -e "  -h|--help: 显示脚本使用帮助\n"

    echo 'For example: $0 -d [{"service_name": "pub-member", "namespace_base": "sat-8972", "docker_label": "daoliu3.0"}] -a xiongjunhua'
    echo -e "\n======================================================\033[0m\n"
	exit 1
}

###清理临时目录
function clean_temp()
{
	if [ -d ${temp_dir} ]
	then
		rm -rf ${temp_dir}
	fi
}


###判断信息是否已存在葛朗台
function is_existing_grandet()
{
	local service_name="$1"
	local get_glt_num_sql='select count(*) from docker_service_grandet where service="'${service_name}'";'
	local num=`${mysql_cmd} -h${db_glt_server} -P${db_glt_port} -u${db_glt_user} -p${db_glt_pass} ${db_glt_name} -e "${get_glt_num_sql}" -N 2>/dev/null`
	
	if [ ${num} -ge 1 ]
	then
		echo "true"
	else
		echo "false"
	fi
}


###基本信息插入葛朗台表中
function insert_grandet()
{
	local service_name="$1"
	local host_name="$2"
	local image_name="$3"
	local memory="$4"
	local port="$5"
	
	local insert_grandet_sql='INSERT INTO `docker_service_grandet` (`service`,`image`,`hostname`,`memory`,`port`,`sub`,`createuser`,`updateuser`,`bootorder`) values 
	("'${service_name}'","'${image_name}'","'${host_name}'","'${memory}'","40191:${port},50191:22022,60191:60191",4,"'${create_user}'","'${create_user}'",51060);'
	
	${mysql_cmd} -h${db_glt_server} -P${db_glt_port} -u${db_glt_user} -p${db_glt_pass} ${db_glt_name} -e "${insert_grandet_sql}" -N 2>/dev/null
}


######## main process
args=`getopt -o d:a:c:h --long details:,applicant:,create_user:,help -n "$0" -- $@`
eval set -- "${args}"

while true
do
    case "$1" in
        -d|--details)
            details=$2
            echo "details:$2"
			
            shift 2
            continue
            ;;
		-a|--applicant)
            applicant=$2
            echo "applicant:$2"
            shift 2
            continue
            ;;
		-c|--create_user)
            create_user=$2
            echo "create_user:$2"
            shift 2
            continue
            ;;
		-h|--help)
            usage_help
            shift
            break
            ;;
        -|--)
            shift
            break
            ;;
        *) 
            message "error" "the option $1 you given is wrong"
            shift
            break
            ;;
    esac
done

if [ -z "${details}" ] || [ -z "${applicant}" ] || [ -z "${create_user}" ]
then
    usage_help
else
	details=${details// /}
	
	service_name_array=(`echo ${details} | jq -r .[].service_name`)
	name_space_array=(`echo ${details} | jq -r .[].name_space`)
	user_label_array=(`echo ${details} | jq -r .[].docker_label`)
	
	if [ ${#service_name_array[@]} -eq ${#name_space_array[@]} ] && [ ${#user_label_array[@]} -eq ${#name_space_array[@]} ]
	then
		message "success" "details参数检查正常"
	else
		message "error" "details中${details}部分参数不正确，请检查"
	fi
fi


create_dir "${temp_dir}"

###拉取非master节点信息
kubectl get node --show-labels --no-headers | grep "Ready" | grep -v 'grandet.nodes.groupname=sat.master' > ${node_info}

if [ ! -s ${node_info} ]
then
	message "error" "kubectl get node --show-labels --no-headers执行失败，请检查"
fi

i=0
while [ $i -lt ${#service_name_array[@]} ]
do
	service_name=${service_name_array[$i]}
	name_space=${name_space_array[$i]}
	user_label=${user_label_array[$i]}

	let i++

	###获取服务相关信息
	service_info=($(get_service_info_cmdb "${service_name}"))
	if [ ${service_info} == "" ]
	then
		message error "get_service_info_cmdb执行失败，请检查"
	fi
	
	product_line=${service_info[0]}
	service_type=${service_info[1]}
	service_port=${service_info[2]}
	tomcat_version=${service_info[3]}
	
	###判断是否已经存在
	container_exist="false"
	
	domain_names=($(get_service_domain_cmdb "${service_name}"))
	if [ "${domain_names}" == "" ]
	then
		message "error" "get_service_domain_cmdb执行失败，请检查"
	fi
	
	for domain_name in ${domain_names[@]}
	do
		container_hostname=${domain_name/.ql.corp/}
		
		flag=$(kind_exist "service" "${container_hostname}" "${name_space}")
		if [ "${flag}" == "true" ]
		then
			container_exist="true"
			break
		fi
	done


	if [ "${container_exist}" == "true" ]
	then
		message "warning" "命名空间${name_space}中容器${container_hostname}已存在，请直接在该容器中直接部署服务即可，跳过容器创建"
		continue
	else
		container_domainname="${domain_names[0]}"
		container_hostname=${container_domainname/.ql.corp/}
	fi

	###根据命名空间得到环境类型是base还是extra
	namespace_reg='sat-[0-9]+'
	if [[ "${name_space}" =~ ${namespace_reg} ]]
	then
		container_env="extra"
	else
		container_env="base"
	fi

	selector_groupname_info=($(get_least_average_limit_mem_rate_group_info "${container_env}"))
	if [ ${#selector_groupname_info[@]} -ne 2 ]
	then
		message "error" "待创建容器的集群名称获取失败，请检查"
	fi
	
	least_mem_rate_group=${selector_groupname_info[0]}
	least_mem_rate=${selector_groupname_info[1]}
	if [ `echo "${max_limit_memory_rate} < ${least_mem_rate}" | bc` -eq 1 ]
	then
		message "error" "由于资源不足，容器创建失败"
	else
		nfs_name=$(get_groupname_nfs "${least_mem_rate_group}")
		if [ "${nfs_name}" == "" ]
		then
			message "error" "待创建容器的NFS名称获取失败，请检查"
		else
			###容器NFS日志及配置存放目录前缀
			nfs_path="/docker/${nfs_name}"
		fi
		
		message "info" "开始在集群${least_mem_rate_group}中创建容器"
		
		create_container "${least_mem_rate_group}" "${service_name}" "${name_space}" "${user_label}" "${container_domainname}" "${container_hostname}"  "${nfs_path}" "${product_line}" "${service_type}" "${service_port}" "${tomcat_version}"
		
		###在10.40.10.37中配置DNS
		config_dnsmasq "${domain_name}"

		###在revoxy_nginx中填加配置
		config_revoxy_nginx "${container_hostname}" "${domain_name}" "${service_port}"
	
		###拷贝base的配置文件到新容器中
		if [ "${container_env}" == "extra" ]
		then
			###判断对应base容器是否存在
			if [ "${service_type}" == "apache" ] || [ "${service_type}" == "nginx" ]
			then
				container_base_exist="false"
				for domain_name in ${domain_names[@]}
				do
					container_base_hostname=${domain_name/.ql.corp/}
					
					flag=$(kind_exist "service" "${container_base_hostname}" "sat-base")
					if [ "${flag}" == "true" ]
					then
						container_base_exist="true"
						break
					fi
				done
				
				if [ "${container_base_exist}" == "false" ]
				then
					if [ "${service_type}" == "apache" ]
					then
						copy_config_from_git "${nfs_path}/${name_space}/config/${container_hostname}"
					fi
				else
					copy_config_from_base "${service_type}" "${container_base_hostname}" "${nfs_path}/${name_space}/config/${container_hostname}" 
				fi
			fi
		fi
		
		###安装qlconfig
		intall_qlconfig "${name_space}" "${container_hostname}"
	fi
done

clean_temp