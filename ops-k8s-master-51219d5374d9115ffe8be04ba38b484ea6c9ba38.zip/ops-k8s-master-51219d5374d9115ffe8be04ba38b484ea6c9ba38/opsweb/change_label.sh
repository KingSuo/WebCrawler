#!/bin/bash

function message()
{
    local message_kind="$1"
    local message_content="$2"

    set +x
    
    case "${message_kind}" in
    error)
        echo -e "\n\033[31m=============================error=============================\033[0m\n"
        echo -e "\033[31merror: ${message_content}\033[0m"
        echo -e "\n\033[31m=============================error=============================\033[0m\n"
        exit 1
        ;;
    success)
        echo -e "\n\033[32m=============================sucess=============================\033[0m\n"
        echo -e "\033[32msucess: ${message_content}\033[0m"
        echo -e "\n\033[32m=============================sucess=============================\033[0m\n"
        ;;
    warning)
        echo -e "\n\033[36m=============================warning=============================\033[0m\n"
        echo -e "\033[36mwarning: ${message_content}\033[0m"
        echo -e "\n\033[36m=============================warning=============================\033[0m\n"
        ;;
    tips)
        #echo -e "\n\033[44;37m==============================================================\033[0m"
        echo -e "\033[44;37m${message_content}\033[0m"
        #echo -e "\033[44;37m==============================================================\033[0m\n"
        ;; 
    esac
    
    set -x
}

#####显示帮助信息
function usage_help()
{
    set +x
    
    echo -e "\n\033[32m======================================================\n"
    echo -e "功能: 修改容器标签"
    echo -e "参数:"
    echo -e "  -s|--service_name: 请填写待修改标签容器的服务名，多个服务时请以逗号,间隔" 
    echo -e "  -l|--label_name: 请填写待修改标签容器的新标签名"
    echo -e "  -n|--name_space: 请填写待修改标签容器的命名空间"
    echo -e "  -h|--help: 显示脚本使用帮助\n"

    echo "For example: $0 -s h5-cwd-vue-admin,h5-rcd-ui-cs -l xjh_label_test -n sat-7090"
    echo -e "\n======================================================\033[0m\n"
    exit 1

    set -x
}

#####获取当前命名空间下的所有服务名称
function get_ns_service_name()
{
    local ns_service_name=(`kubectl get po -n ${name_space} -o wide --show-labels | awk -F 'hostname=' '{print $2}' | awk -F ',' '{print $1}' |  sed -e '/^$/d'  2>/dev/null`)

    echo "${ns_service_name[@]}"
}



#####获取当前标签名称
function get_current_label()
{
    local kind="$1"
	local kind_name="$2"

    local current_label=`kubectl get ${kind} ${kind_name} --namespace=${name_space} --show-labels  | awk -F 'userlabel=' '{print $2}' |  sed -e '/^$/d' 2>/dev/null`

    echo "${current_label}"
}


####获取pod,deployments\replicasets和services名称
function get_kind_name()
{   
    local kind="$1"
	local service="$2"

    kind_name=(`kubectl get ${kind} --namespace=${name_space} -l hostname=${service} -o name | awk -F '/' '{print $2}'`)
    if [ "${kind_name}" == "" ]
    then
        message "error" "${kind}：服务${service} ${kind}的name获取失败，请检查"
    fi
}


####更新标签
function update_label()
{
    local kind="$1"
    local kind_name="$2"
    
    kubectl label --overwrite ${kind} ${kind_name} --namespace=${name_space} userlabel=${label_name}
    
    if [ $? -ne 0 ]
    then
        message "error" "kubectl label --overwrite ${kind} ${kind_name} --namespace=${name_space} userlabel=${label_name}执行失败，请检查"
    fi
}


######## main process
args=`getopt -o s:l:n:h --long service_name:,label_name:,name_space:,help -n "$0" -- $@`
eval set -- "${args}"

while true
do
    case "$1" in
        -s|--service_name)
            export service_name=$2
			echo "service_name:$2"
            shift 2
            continue
            ;;
        -l|--label_name)
            export label_name=$2
            echo "label_name:$2"
            shift 2
            continue
            ;;
        -n|--name_space)
            export name_space=$2
            echo "name_space:$2"
            shift 2
            continue
            ;;
        -h|--help)
            usage_help
            shift
            break
            ;;
        --)
            shift
            break
            ;;
        *) 
            message "error" "the option $1 you given is wrong"
            shift
            break
            ;;
    esac
done

if [ -z "${service_name}" ] || [ -z "${label_name}" ] || [ -z "${name_space}" ]
then
    usage_help
fi


kind_array=("pod" "deployments" "replicasets" "services")

if [ "${service_name}" == "all" ]
then
	service_name=($(get_ns_service_name))
	if [ "${service_name}" == "" ]
	then
		message "error" "获取当前命名空间${name_space}下的所有服务名称"
	else
		message "success" "命名空间${name_space}下的所有服务名称为${service_name[@]}"
	fi
else
	service_name=${service_name//,/ }
fi

for service in ${service_name[@]}
do
	for kind in ${kind_array[@]}
	do
		kind_name=""   
		get_kind_name "${kind}" "${service}"
		
		for name in ${kind_name[@]}
		do
			current_label=$(get_current_label "${kind}" "${name}")
			case "${current_label}" in
				"${label_name}")
					message "warning" "服务${service} ${kind} ${name} 现有标签和待更新的标签都为${label_name}，跳过处理"
					continue
					;;
				"")
					message "error" "服务${service} ${kind} ${name} 现有标签获取失败，请检查"
					;;
				*)

					update_label "${kind}" "${name}"
					
					new_label_name=$(get_current_label "${kind}" "${name}")
					if [ "${new_label_name}" == "${label_name}" ]
					then
						message "success" "${kind}：服务${service} ${kind} ${name} 标签已成功从${current_label}更新为${label_name}"
					else
						message "error" "${kind}：服务${service} ${kind} ${name} 标签未成功从${current_label}更新为${label_name}，请检查"
					fi
					;;
			esac
		done
	done
done