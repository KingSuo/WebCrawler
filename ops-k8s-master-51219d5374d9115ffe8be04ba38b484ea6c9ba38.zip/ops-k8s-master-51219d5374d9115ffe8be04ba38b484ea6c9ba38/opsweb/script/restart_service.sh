#!/bin/bash

imagetype=$1
nettysvc=$2

#### functions #################
function NettyFileInit(){
  jar_name=$1
  snowwalk=$2
  if [ -e /etc/init.d/${jar_name} ];then
    if [ -d "/opt/script/snowwalking-agent" ];then
      str1='\      -javaagent:/opt/script/snowwalking-agent/jre-agent.jar \\'
      str2='\      -javaagent:/opt/script/snowwalking-agent/transmittable-thread-local-2.2.0.jar \\'
      str3='\      -javaagent:/opt/script/snowwalking-agent/snowwalking-agent.jar \\'
      str4='\      -Xbootclasspath/a:/opt/script/snowwalking-agent/snowwalking-agent.jar \\'
      snowwalkstatus=`sed -n '/snowwalking/=' /etc/init.d/${jar_name}`
      if [ -z "${snowwalkstatus}" ];then
        pre_line=`sed -n "/^\s*-jar/=" /etc/init.d/${jar_name}`
        sed -i "${pre_line}i ${str4}" /etc/init.d/${jar_name}
        sed -i "${pre_line}i ${str3}" /etc/init.d/${jar_name}
        sed -i "${pre_line}i ${str2}" /etc/init.d/${jar_name}
        sed -i "${pre_line}i ${str1}" /etc/init.d/${jar_name}
      fi
    fi
  fi
}


function TomcatFileInit(){
  jar_name=$1

  if [ -e /etc/init.d/${jar_name} ];then
    if [ -d "/opt/script/snowwalking-agent" ];then
      str1='\JAVA_OPTS="$JAVA_OPTS -javaagent:/opt/script/snowwalking-agent/jre-agent.jar -javaagent:/opt/script/snowwalking-agent/transmittable-thread-local-2.2.0.jar -javaagent:/opt/script/snowwalking-agent/snowwalking-agent.jar -Xbootclasspath/a:/opt/script/snowwalking-agent/snowwalking-agent.jar"'
      snowwalkstatus=`sed -n '/snowwalking/=' /etc/init.d/${jar_name}`
      if [ -z "${snowwalkstatus}" ];then
        pre_line=`sed -n "/^CATALINA_PID=\/opt\/tomcat/=" /etc/init.d/${jar_name}`
        sed -i "${pre_line}i ${str1}" /etc/init.d/${jar_name}
      fi
    fi
  fi
}

function OtherInit(){
  grep DUBBO /root/.bashrc > /dev/null
  if [ $? -ne 0 ]; then
    export LD_ASSUME_KERNEL=4.4.84;export DUBBO_PORT=20880;export REDIS_PORT=6379; export MONGODB_PORT=27017; echo "export LD_ASSUME_KERNEL=4.4.84;export DUBBO_PORT=20880;export REDIS_PORT=6379; export MONGODB_PORT=27017;" >> /root/.bashrc;
  fi
  
  ls /mobankerdata1/appdatas/cat/client.xml > /dev/null
  if [ $? -eq 0 ]; then
    sed -i "s/192.168.1.170/cat01.oa.ops/g;s/192.168.1.11/cat02.oa.ops/g;s/192.168.1.15/cat03.oa.ops/g;" /mobankerdata1/appdatas/cat/client.xml
  fi
}

OtherInit


image_short=$(awk -F'=' '/^pod.image=/{print $2}' /opt/script/pod.properties)
if [ -f "/opt/script/pod.properties" ]; then  
  svc_name=$(awk -F'=' '/^pod.service=/{print $2}' /opt/script/pod.properties)
  [[ -n "${svc_name}" ]] && nettysvc="${svc_name}";
fi
[[ "${image_short}" == "netty_"* ]] && imagetype="netty";
[[ "${image_short}" == "nginx"* ]] && imagetype="nginx";
[[ "${image_short}" == "webserver"* ]] && imagetype="webserver";
[[ "${image_short}" == "tomcat8_"* ]] && imagetype="tomcat8";
[[ "${image_short}" == "tomcat_"* ]] && imagetype="tomcat7";


if [ "$imagetype" == "nginx" ];then
  ls /etc/init.d/nginx > /dev/null
  if [ $? -eq 0 ]; then
   /etc/init.d/nginx stop;
   sleep 1;
   /etc/init.d/nginx start;
  fi
fi

if [ "${imagetype}" == "netty" ];then
  ls /etc/init.d/"${nettysvc}" > /dev/null
  if [ $? -eq 0 ]; then

    NettyFileInit "${nettysvc}"

    /etc/init.d/${nettysvc} restart;
    sleep 1;
    ps aux|grep java|grep -v defunct|grep -v grep;
  fi
fi

if [ "${imagetype}" == "tomcat7" ];then
  ls /etc/init.d/tomcat7 > /dev/null
  if [ $? -ne 0 ]; then
    exit 1;
  fi

  TomcatFileInit "tomcat7"

  ps -ef |grep java |grep tomcat | grep -v grep > /dev/null
  if [ $? -eq 0 ]; then
    /etc/init.d/tomcat7 stop
    echo "---"
    sleep 3
    ps -ef | grep tomcat | grep -v grep |  awk '{print $2}'|xargs kill -9
  fi
  sleep 1;
  . /etc/init.d/tomcat7 start;
  sleep 1;
  ps aux|grep java|grep -v defunct|grep -v grep;
fi

if [ "${imagetype}" == "tomcat8" ];then
  ls /etc/init.d/tomcat8 > /dev/null
  if [ $? -ne 0 ]; then
    exit 1;
  fi

  TomcatFileInit "tomcat8"

  chmod +x /etc/init.d/tomcat8 > /dev/null

  ps -ef |grep java |grep tomcat | grep -v grep > /dev/null
  if [ $? -eq 0 ]; then
    /etc/init.d/tomcat8 stop
    echo "---"
    sleep 3
    ps -ef | grep tomcat | grep -v grep |  awk '{print $2}'|xargs kill -9
  fi
  sleep 1;
  . /etc/init.d/tomcat8 start;
  sleep 1;
  ps aux|grep java|grep -v defunct|grep -v grep;
fi
